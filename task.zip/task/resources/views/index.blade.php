<!DOCTYPE html>
<html>
<head>
	<title>Users and Tasks</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">

	<link rel="stylesheet" type="text/css" href="/Datatables/datatables.css">
	<link rel="stylesheet" type="text/css" href="/Datatables/datatables.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="/css/style.css">


</head>
<body>
    <div class="container main">
        <center><h2 class="common-header">Users and Tasks</h2><br></center>
        <ul class="nav nav-tabs">
	        <li class="active"><a data-toggle="tab" href="#home">Users</a></li>
	        <li><a data-toggle="tab" href="#menu1">Tasks</a></li>
        </ul>
        <div class="tab-content">
		    <div id="home" class="tab-pane fade in active"><br>
	            <table id="userTable" class="display" style="width:100%">
		            <thead>
			            <tr>
			                <th>Name</th>
			                <th>Email</th>
			                <th>Mobile</th>
			                <th>Added at</th>
			                <th>Updated at</th>
			            </tr>
			        </thead>
			        <tbody>
			        	@foreach($users as $user)
			            <tr>
			                <td>{{ $user->name }}</td>
			                <td>{{ $user->email }}</td>
			                <td>{{ $user->mobile }}</td>
			                <td>{{ $user->created_at }}</td>
			                <td>{{ $user->updated_at }}</td>
			            </tr>
			            @endforeach
			        </tbody>
	            </table> 
		        <!-- Model      -->
	        	<!-- Trigger the modal with a button -->
	            <div  class="modelbtn">
		        	<button type="button" class="btnOpenModel" data-toggle="modal" data-target="#myModal">Add user</button>
	            </div>
	            <div  class="exportbtn">
	            	<button type="button" class="btnOpenModel" onclick="exportConfirm('/export/user')">Export</button>
	            </div>
	        	  <!-- Modal -->
	        	<div class="modal fade" id="myModal" role="dialog">
	        	    <div class="modal-dialog user">
        	    
	        	      <!-- Modal content-->
	        	      <div class="modal-content">
	        	        <div class="modal-header">
	        	          <button type="button" class="close" data-dismiss="modal">&times;</button>
	        	          <center><h4 class="modal-title">Add user</h4></center>
	        	        </div>
	        	        <div class="modal-body usermodel">
	        	            <div class="success" id="signupSuccess"></div>
							<form id="userForm">
								<label for="name">Full name</label>
								<input type="name" name="name" class="form-control user" id="">
								<p class="formError" id="errName"></p>
								<label for="email">Email address</label>
								<input type="email" class="form-control user" name="email" id="">
								<p class="formError" id="errEmail"></p>
								<label for="mobile">Mobile</label>
								<input type="text" class="form-control user" id="" name="mobile" >
								<p class="formError" id="errMobile"></p>
							<!-- </form> -->
	        	        </div>
	        	        <div class="modal-footer">
					      <button type="submit" class="mybtn btnsave" id="btn1">Save</button>
					      <img src="/images/loader.gif" class="loader" id="loader1" hidden>
	        	        </div>
	        	        </form>
	        	    </div>
        	    </div>
        	</div>
        </div>
        <div id="menu1" class="tab-pane fade">
			<table id="taskTable" class="display" style="width:100%">
	            <thead>
		            <tr>
		                <th>Task Name</th>
		                <th>Task Type</th>
		                <th>User</th>
		                <th>Added at</th>
		                <th>Updated at</th>
		            </tr>
		        </thead>
		        <tbody>
		        	@foreach($tasks as $task)
		            <tr>
		                <td>{{ $task->name }}</td>
		                <td>{{ $task->type }}</td>
		                <td>{{ $task->user_name }}</td>
		                <td>{{ $task->created_at }}</td>
		                <td>{{ $task->updated_at }}</td>
		            </tr>
		            @endforeach
		        </tbody>
            </table>
            <!-- Model      -->
	        	<!-- Trigger the modal with a button -->
				<div  class="modelbtn">
		        	<button type="button" class="btnOpenModel" data-toggle="modal" data-target="#myModal1">Add task</button>
	            </div>
	            <div  class="exportbtn">
		        	<button type="button" class="btnOpenModel" onclick="exportConfirm('/export/task')">Export</button>
	            </div>
	        	  <!-- Modal -->
	        	<div class="modal fade" id="myModal1" role="dialog">
	        	    <div class="modal-dialog user">
        	    
	        	      <!-- Modal content-->
	        	      <div class="modal-content">
	        	        <div class="modal-header">
	        	          <button type="button" class="close" data-dismiss="modal">&times;</button>
	        	          <center><h4 class="modal-title">Add tasks</h4></center>
	        	        </div>
	        	        <div class="modal-body taskmodel">
	        	            <div class="success" id="taskSaved"></div>
	        	            <form id="taskForm">
							<label for="">Select user</label>
							<select class="form-control user" id="selectUser" name="user_id">
								<option>Select user</option>
								@foreach($users as $user)
									<option value="{{ $user->id }}">{{ $user->name }}</option>
								@endforeach
							</select>
							<p class="formError" id="errSelect"></p>
							<label for="">Task name</label>
							<input type="name" name="task_name" class="form-control user" id="">
							<p class="formError" id="errTaskName"></p>
							<label for="exampleSelect1">Task type</label><br>
							<div class="taskType">
								<input type="radio" name="task_type" value="pending"> <span class="taskType pending">Pending</span> 
					            <input type="radio" name="task_type" value="done"> <span class="">Done</span>
							<p class="formError taskType" id="errTaskType"></p>
					        </div>
						    <!-- </form> -->
	        	        </div>
	        	        <div class="modal-footer">
					      <button type="submit" class="mybtn btnsave" id="btn2">Save</button>
					      <img src="/images/loader.gif" class="loader" id="loader2" hidden>
	        	        </div>
	        	        </form>
	        	    </div>
        	    </div>
        </div>
    </div>
</div>
</body>

<!-- <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script> -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/Datatables/datatables.js"></script>
<script type="text/javascript" src="/Datatables/datatables.min.js"></script>
<!-- <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script> -->
<script type="text/javascript">

    $(document).ready(function(){

	    $('#userTable').dataTable();
	    $('#taskTable').dataTable();
			
		       /**************process the form***********/
        $('#userForm').submit(function(event) {
        	document.getElementById("signupSuccess").innerHTML ="";
            
            loader("show", 1);
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            event.preventDefault();
            var formData = $(this).serialize();
            // console.log(formData); 
        
            $.ajax({
                type        : 'POST', // define the type of HTTP verb we want to use (POST for our form)
                url         : '/user', // the url where we want to POST
                data        : formData, // our data object

                error: function(data){
	            sleep(1000);
                    var result = data.responseJSON;
                    if(data.status==422){
                    	hideErrors("formError");
                        var errMsg = "";
                        for(error in result.errors){
                            errMsg = result.errors[error]+"";
							if(errMsg.includes("name")){
							    document.getElementById("errName").innerHTML = errMsg;
							}
							else if(errMsg.includes("email")){
							    document.getElementById("errEmail").innerHTML = errMsg;
							}
							else if(errMsg.includes("mobile")){
							    document.getElementById("errMobile").innerHTML = errMsg;
							}
	                       // console.log(errMsg);
                        }
                    }
                    loader("hide", 1);
                }
            })
                // using the done promise callback
            .done(function(result) {
                sleep(1000);
                loader("hide", 1);
                if(result){
                	hideErrors("formError");
                	document.getElementById("userForm").reset();
                	document.getElementById("signupSuccess").innerHTML = "Details saved successfully.";
                	addOption(result);
                }
            });

        });//User form ends


    /**************process the task form***********/
        $('#taskForm').submit(function(event) {
        	// document.getElementById("signupSuccess").innerHTML ="";
            
            loader("show", 2);
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            event.preventDefault();
            var formData = $(this).serialize();
            // console.log(formData); 
        
            $.ajax({
                type        : 'POST', // define the type of HTTP verb we want to use (POST for our form)
                url         : '/task', // the url where we want to POST
                data        : formData, // our data object

                error: function(data){
	            sleep(1000);
                    var result = data.responseJSON;
                    if(data.status==422){
                    	console.log(result.errors);
                    	hideErrors("formError");
                        var errMsg = "";
                        for(error in result.errors){
                            errMsg = result.errors[error]+"";
							if(errMsg.includes("user id")){
							    document.getElementById("errSelect").innerHTML = "Select user.";
							}
							else if(errMsg.includes("task name")){
							    document.getElementById("errTaskName").innerHTML = errMsg;
							}
							else if(errMsg.includes("task type")){
							    document.getElementById("errTaskType").innerHTML = "Choose task type.";
							}
                        }
                    }
                   loader("hide", 2);
                }
            })
                // using the done promise callback
            .done(function(result) {
            	console.log(result);
                sleep(1000);
                if(result){
                	hideErrors("formError");
                	document.getElementById("taskForm").reset();
                	document.getElementById("taskSaved").innerHTML = "Task saved successfully.";
                	// addOption(result);
                }
                loader("hide", 2);
            });

        });// Task form ends
    });

    function hideErrors(className) {
    	var x = document.getElementsByClassName(className);
    	for (var i = 0; i < x.length; i++) {
    		x[i].innerHTML = "";
    	}
    }

    function sleep(milliseconds) {
      var start = new Date().getTime();
      for (var i = 0; i < 1e7; i++) {
        if ((new Date().getTime() - start) > milliseconds){
          break;
        }
      }
    }

    function loader(val, id) {
    	if(val==="show"){
	    	document.getElementById("btn"+id).hidden = true; 
	        document.getElementById("loader"+id).hidden = false;
	    }
	    else if(val==="hide"){
	    	document.getElementById("btn"+id).hidden = false; 
            document.getElementById("loader"+id).hidden = true;
	    }
    }

    function addOption(data) {
    	var x = document.getElementById("selectUser");
	    var option = document.createElement("option");
	    option.text = data.name;
	    option.value = data.id;
	    x.add(option);
    }
    
    function exportConfirm(url) {
	    if(confirm("Excel file will be downloaded. Click OK to confirm.")){
	    	window.location = url;
		}
    }
</script>
            
</html>