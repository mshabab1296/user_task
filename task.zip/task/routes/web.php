<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'HomeController@index')->name('home');

Route::post('/user', 'UserController@store');
Route::post('/task', 'TaskController@store');


Route::get('/export/user', function(){
	return \Excel::download(new App\Exports\UsersExport, 'users.xlsx');
})->name('export.users');

Route::get('/export/task', function(){
	return \Excel::download(new App\Exports\TasksExport, 'tasks.xlsx');
})->name('export.tasks');

