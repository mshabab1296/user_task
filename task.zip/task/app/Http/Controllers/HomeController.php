<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Task;

class HomeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
    	$users = User::all();
    	$task = new Task();
    	$tasks = $task->tasksWithUsers();
    	// return $tasks;
        return view('index')->with(compact('users', 'tasks'));
    }
}
