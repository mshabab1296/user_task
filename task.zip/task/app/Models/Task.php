<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class Task extends Model
{
    public function tasksWithUsers()
    {
    	$tasks  = DB::table('tasks')
    			  ->leftjoin('users', 'users.id', '=', 'tasks.user_id')
    			  ->select('tasks.*','users.name as user_name')
    			  ->get();
        return $tasks;
    }
}
