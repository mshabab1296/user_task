<?php
namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromCollection;
use App\Models\Task;
use Illuminate\Support\Collection;


class TasksExport implements FromCollection{
    public function collection()
    {
    	$task = new Task();
    	$tasks = $task->tasksWithUsers();
    	$task_array[] = array('Task id', 'Task name', 'Task type', 'User name', 'Added at', 'Updated_at');

    	foreach ($tasks as $tsk) {
    		$task_array[] = array(
    			'Task id' => $tsk->id,
    			'Task name' => $tsk->name,
    			'Task type' => $tsk->type,
    			'User name' => $tsk->user_name,
    			'Added at' => $tsk->created_at,
    			'Updated at' => $tsk->updated_at
    		);
        }

        return new Collection($task_array);
    }
}