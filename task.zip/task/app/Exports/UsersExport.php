<?php
namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromCollection;
use App\Models\User;
use Illuminate\Support\Collection;


class UsersExport implements FromCollection{
    public function collection()
    {
        $users = User::all();
        $user_array[] = array('Id', 'Name', 'Email', 'Mobile', 'Added at', 'Updated at');
        foreach ($users as $user) {
    		$user_array[] = array(
    			'Id' => $user->id,
    			'Name' => $user->name,
    			'Email' => $user->email,
    			'Mobile' => $user->mobile,
    			'Added at' => $user->created_at,
    			'Updated at' => $user->updated_at
    		);
        } 
        return new Collection($user_array);
    }
}